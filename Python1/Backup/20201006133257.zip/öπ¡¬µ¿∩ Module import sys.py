import sys
import os
print('Аргумент командной строки:')
for i in sys.argv:
    print(i)

print('\n\nПеременная PYTHONPATH содержит', sys.path,'\n')
print(os.getcwd())