import mymodule
mymodule.sayhi()
print('Версия', mymodule.__version__)
